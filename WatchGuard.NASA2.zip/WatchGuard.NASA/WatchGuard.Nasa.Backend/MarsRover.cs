﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using Newtonsoft.Json;


namespace WatchGuard.Nasa.Backend
{
    public class MarsRover
    {

        public Photos GetDetails(string date)
        {
            string response;
            var photos = new Photos();
            photos.PhotoDetails = new List<Photo>();

            using (var httpClient = new HttpClient())
            {
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                Uri url = new Uri($"https://api.nasa.gov/mars-photos/api/v1/rovers/curiosity/photos?earth_date={date}&api_key=DEMO_KEY");
                response = httpClient.GetStringAsync(url).Result;
            }

            // Not sure what's going on here, so quickly wrote below function that parses out the images
            //var photos = JsonConvert.DeserializeObject<photos>(response);
            var images = GetAllImages(response);
            foreach (var image in images)
            {
                photos.PhotoDetails.Add(new Photo { img_src = image });
            }

            return photos;
        }


        private List<string> GetAllImages(string text)
        {
            const string img_src = "img_src";
            List<string> images = new List<string>();

            int index = 0;
            while ((index = text.IndexOf(img_src, index)) != -1)
            {
                index += img_src.Length + "\":\"".Length;

                var imageSource = text.Substring(index, text.IndexOf('\"', index) - index);
                images.Add(imageSource);

                index += imageSource.Length;
            }

            return images;
        }


        public static List<string> GetDates()
        {
            var dates = new List<string>();

            using (StreamReader sr = new StreamReader("C:\\dates.txt"))
            {
                var line = sr.ReadLine();
                while (line != null)
                {
                    dates.Add(line);

                    // Read the next line
                    line = sr.ReadLine();
                }
            }

            return dates;
        }

    }
}
