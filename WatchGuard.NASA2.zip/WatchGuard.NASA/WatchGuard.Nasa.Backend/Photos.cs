﻿using System;
using System.Collections.Generic;
using System.Text;


namespace WatchGuard.Nasa.Backend
{
    public class Photos
    {
        public List<Photo> PhotoDetails { get; set; }
    }
}
