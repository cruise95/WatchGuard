﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WatchGuard.Nasa.Backend
{
    public class Photo
    {
        public int id { get; set; }
        public string img_src { get; set; }
    }
}
