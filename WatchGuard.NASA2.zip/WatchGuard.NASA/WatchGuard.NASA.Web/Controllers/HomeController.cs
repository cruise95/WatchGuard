﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using WatchGuard.NASA.Web.Models;


namespace WatchGuard.NASA.Web.Controllers
{
    public class HomeController : Controller
    {
        public HomeController()
        { }


        public IActionResult Index()
        {
            var captureDates = WatchGuard.Nasa.Backend.MarsRover.GetDates();

            return View(captureDates);
        }


        public ActionResult MarsRover(string date)
        {
            // Convert date
            DateTime parsedDate; 
            var selectedDate = Request.Form["ddlDates"].ToString();
            var result = DateTime.TryParse(selectedDate, out parsedDate);

            string convertedDate = string.Empty;
            string errorMsg = string.Empty;
            if (result)
            {
                convertedDate = parsedDate.ToString("yyyy-MM-dd");
                var marsRover = new WatchGuard.Nasa.Backend.MarsRover();

                //List<WatchGuard.Nasa.Backend.Photo> photos = marsRover.GetDetails(convertedDate);
                WatchGuard.Nasa.Backend.Photos photos = marsRover.GetDetails(convertedDate);
                return View(photos);
            }
            else
            {
                errorMsg = "This is not a valid date";
                return Content(errorMsg);
            }
        }

    }
}
