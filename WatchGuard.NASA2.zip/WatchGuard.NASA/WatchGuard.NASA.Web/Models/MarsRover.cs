﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WatchGuard.NASA.Web.Models
{
    public class MarsRover
    {
        public string CaptureDate;

        public static MarsRover Map(string date)
        {
            var marsRover = new MarsRover()
            {
                CaptureDate = date
            };

            return marsRover;
        }

        public static List<MarsRover> Map(List<string> dates)
        {
            var marsRovers = new List<MarsRover>();
            dates.ForEach(d => {
                marsRovers.Add(new MarsRover { CaptureDate = d });
            });

            return marsRovers;
        }

    }
}
