﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using WatchGuard.NASA.Web.Models;


namespace WatchGuard.NASA.Web.Controllers
{
    public class HomeController : Controller
    {
        public HomeController()
        { }


        public IActionResult Index(string date)
        {
            var captureDates = WatchGuard.Nasa.Backend.MarsRover.GetDates();

            return View(captureDates);
        }


        public ActionResult MarsRover(string date)
        {
            var marsRover = new WatchGuard.Nasa.Backend.MarsRover();
            string response = marsRover.GetDetails("2015-6-3");
            //string response = marsRover.GetDetails(date);

            if (response.Length > 0)
                return Content(response);
            else
                return Content(date);
        }

    }
}
