﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WatchGuard.NASA.Web.Models
{
    public class MarsRover
    {
        public string CaptureDate;
    }
}
