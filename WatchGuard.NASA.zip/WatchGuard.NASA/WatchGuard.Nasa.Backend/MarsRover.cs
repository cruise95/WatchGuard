﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;


namespace WatchGuard.Nasa.Backend
{
    public class MarsRover
    {

        public string GetDetails(string date)
        {

            using (var httpClient = new HttpClient())
            {
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                Uri url = new Uri($"https://api.nasa.gov/mars-photos/api/v1/rovers/curiosity/photos?earth_date={date}&api_key=DEMO_KEY");

                var response = httpClient.GetStringAsync(url).Result;
                return response;
            }

        }


        public static List<string> GetDates()
        {
            var dates = new List<string>();

            using (StreamReader sr = new StreamReader("C:\\dates.txt"))
            {
                var line = sr.ReadLine();
                while (line != null)
                {
                    dates.Add(line);

                    // Read the next line
                    line = sr.ReadLine();
                }
            }

            return dates;
        }

    }
}
